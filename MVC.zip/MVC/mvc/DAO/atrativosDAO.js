const atrativos = require('../models/atrativoModel')
const Db = require('../../repository/bancoDados')

class AtrativosDAO{
    #db
    constructor(){
        this.#db = db
    }
    async ConsultarAtrativos(){
        let list_atrativos = []

        const query = await this.#db.buscarAtrativos()
        for(let i = 0; i < query.length; i++){
        const vendas = new vendas()

        atrativos.id = query[i].atrativosId
        atrativos.nome = query[i].atrativosNome
        atrativos.latitude = query[i].atrativosLatitude
        atrativos.longitude = query[i].atrativosLongitude
        atrativos.descricao = query[i].atrativosDescricao
        atrativos.imagem = query[i].atrativosImagem

        list_atrativos.push(atrativos.toJson())
        }
        
    }
}
module.exports = AtrativosDAO