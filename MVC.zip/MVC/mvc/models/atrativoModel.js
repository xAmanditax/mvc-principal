class Atrativo{
    id
    nome
    latitude
    longitude
    descricao
    imagem

    constructor(id, nome, latitude, longitude, descricao, imagem){
        this.id = id
        this.nome = nome
        this.latitude = latitude
        this.longitude = longitude
        this.descricao = descricao
        this.imagem = imagem
    }
}