class Personagens {

    poder
    nome
    genero
    tamanho
    profissao

    constructor(poder, nome, genero, tamanho, profissao){
        this.poder = poder
        this.nome = nome
        this.genero = genero
         
    }

    pegarInformacoes(){
        return{
            "poder" : this.poder,
            "nome" : this.nome,
            "genero" : this.genero
    }
    }

   

}

let person = new Personagens("Girar", "Crash", "Marsupial") 
console.log(person.poder+" "+person.genero+" "+person.nome)

module.exports = Personagens