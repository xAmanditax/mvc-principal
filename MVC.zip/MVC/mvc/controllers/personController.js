const Personagens = require('../models/personagemModel.js')

module.exports = (app) => {
    app.get("/getAllPersons", (req, res) => {
        res.json({
            "status": "ok"
        })
    
   
    })

}



