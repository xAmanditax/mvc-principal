const AtrativosDAO = require('../DAO/atrativosDAO')

module.exports = (app) => {
    app.get('/getAllAtrativos', async(req, res) => {
        const atrativosDAO = new atrativosDAO()
        res.setHeader('Access-Control-Allow-Origin','*')
        res.json(await atrativosDAO.ConsultarTodos())
        
    })
}